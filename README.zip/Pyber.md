

```python
# Dependencies
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
```


```python
# Load in csv
city_df = pd.read_csv("raw_data/city_data.csv")
rides_df = pd.read_csv("raw_data/ride_data.csv")
```


```python
clean_city = pd.DataFrame({'type': city_df.groupby('city').first()['type'],
                                'driver_count': city_df.groupby('city').sum()['driver_count']}).reset_index()
clean_city
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>67</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>16</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>21</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>49</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Arnoldview</td>
      <td>41</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Campbellport</td>
      <td>26</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Carrollbury</td>
      <td>4</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Carrollfort</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Clarkstad</td>
      <td>21</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Conwaymouth</td>
      <td>18</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Davidtown</td>
      <td>73</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Davistown</td>
      <td>25</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>13</th>
      <td>East Cherylfurt</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>14</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>15</th>
      <td>East Erin</td>
      <td>43</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>16</th>
      <td>East Jenniferchester</td>
      <td>22</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>17</th>
      <td>East Leslie</td>
      <td>9</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>18</th>
      <td>East Stephen</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>19</th>
      <td>East Troybury</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Edwardsbury</td>
      <td>11</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Erikport</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Eriktown</td>
      <td>15</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Floresberg</td>
      <td>7</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Fosterside</td>
      <td>69</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Hernandezshire</td>
      <td>10</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Horneland</td>
      <td>8</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Jacksonfort</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Jacobfort</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Jasonfort</td>
      <td>25</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>South Roy</td>
      <td>35</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>96</th>
      <td>South Shannonborough</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>97</th>
      <td>Spencertown</td>
      <td>68</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>98</th>
      <td>Stevensport</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Stewartview</td>
      <td>49</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>100</th>
      <td>Swansonbury</td>
      <td>64</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>101</th>
      <td>Thomastown</td>
      <td>1</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>102</th>
      <td>Tiffanyton</td>
      <td>21</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>103</th>
      <td>Torresshire</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>104</th>
      <td>Travisville</td>
      <td>37</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>105</th>
      <td>Vickimouth</td>
      <td>13</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Webstertown</td>
      <td>26</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>107</th>
      <td>West Alexis</td>
      <td>47</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>108</th>
      <td>West Brandy</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>109</th>
      <td>West Brittanyton</td>
      <td>9</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>110</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>111</th>
      <td>West Evan</td>
      <td>4</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>112</th>
      <td>West Jefferyfurt</td>
      <td>65</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>113</th>
      <td>West Kevintown</td>
      <td>5</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>114</th>
      <td>West Oscar</td>
      <td>11</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>115</th>
      <td>West Pamelaborough</td>
      <td>27</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>116</th>
      <td>West Paulport</td>
      <td>5</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>117</th>
      <td>West Peter</td>
      <td>61</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>118</th>
      <td>West Sydneyhaven</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>119</th>
      <td>West Tony</td>
      <td>17</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>120</th>
      <td>Williamchester</td>
      <td>26</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>121</th>
      <td>Williamshire</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>122</th>
      <td>Wiseborough</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>123</th>
      <td>Yolandafurt</td>
      <td>7</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>124</th>
      <td>Zimmermanmouth</td>
      <td>45</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 3 columns</p>
</div>




```python
avg_fare=rides_df.groupby("city")["fare"].mean()
total_fare=rides_df.groupby("city")["fare"].sum()
total_drivers=city_df.groupby("city")["driver_count"].sum()
total_rides=rides_df.groupby("city")["ride_id"].count()

calc_table=pd.DataFrame ({"Average Fare": avg_fare,
                          "Total Fare": total_fare,
                          "Total Drivers": total_drivers,
                          "Total Rides": total_rides,
                        })
calc_table.reset_index(inplace=True)
calc_table
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>Average Fare</th>
      <th>Total Drivers</th>
      <th>Total Fare</th>
      <th>Total Rides</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>23.928710</td>
      <td>21</td>
      <td>741.79</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>20.609615</td>
      <td>67</td>
      <td>535.85</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>37.315556</td>
      <td>16</td>
      <td>335.84</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>23.625000</td>
      <td>21</td>
      <td>519.75</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>21.981579</td>
      <td>49</td>
      <td>417.65</td>
      <td>19</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Arnoldview</td>
      <td>25.106452</td>
      <td>41</td>
      <td>778.30</td>
      <td>31</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Campbellport</td>
      <td>33.711333</td>
      <td>26</td>
      <td>505.67</td>
      <td>15</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Carrollbury</td>
      <td>36.606000</td>
      <td>4</td>
      <td>366.06</td>
      <td>10</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Carrollfort</td>
      <td>25.395517</td>
      <td>55</td>
      <td>736.47</td>
      <td>29</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Clarkstad</td>
      <td>31.051667</td>
      <td>21</td>
      <td>372.62</td>
      <td>12</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Conwaymouth</td>
      <td>34.591818</td>
      <td>18</td>
      <td>380.51</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Davidtown</td>
      <td>22.978095</td>
      <td>73</td>
      <td>482.54</td>
      <td>21</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Davistown</td>
      <td>21.497200</td>
      <td>25</td>
      <td>537.43</td>
      <td>25</td>
    </tr>
    <tr>
      <th>13</th>
      <td>East Cherylfurt</td>
      <td>31.416154</td>
      <td>9</td>
      <td>408.41</td>
      <td>13</td>
    </tr>
    <tr>
      <th>14</th>
      <td>East Douglas</td>
      <td>26.169091</td>
      <td>12</td>
      <td>575.72</td>
      <td>22</td>
    </tr>
    <tr>
      <th>15</th>
      <td>East Erin</td>
      <td>24.478214</td>
      <td>43</td>
      <td>685.39</td>
      <td>28</td>
    </tr>
    <tr>
      <th>16</th>
      <td>East Jenniferchester</td>
      <td>32.599474</td>
      <td>22</td>
      <td>619.39</td>
      <td>19</td>
    </tr>
    <tr>
      <th>17</th>
      <td>East Leslie</td>
      <td>33.660909</td>
      <td>9</td>
      <td>370.27</td>
      <td>11</td>
    </tr>
    <tr>
      <th>18</th>
      <td>East Stephen</td>
      <td>39.053000</td>
      <td>6</td>
      <td>390.53</td>
      <td>10</td>
    </tr>
    <tr>
      <th>19</th>
      <td>East Troybury</td>
      <td>33.244286</td>
      <td>3</td>
      <td>232.71</td>
      <td>7</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Edwardsbury</td>
      <td>26.876667</td>
      <td>11</td>
      <td>725.67</td>
      <td>27</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Erikport</td>
      <td>30.043750</td>
      <td>3</td>
      <td>240.35</td>
      <td>8</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Eriktown</td>
      <td>25.478947</td>
      <td>15</td>
      <td>484.10</td>
      <td>19</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Floresberg</td>
      <td>32.310000</td>
      <td>7</td>
      <td>323.10</td>
      <td>10</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Fosterside</td>
      <td>23.034583</td>
      <td>69</td>
      <td>552.83</td>
      <td>24</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Hernandezshire</td>
      <td>32.002222</td>
      <td>10</td>
      <td>288.02</td>
      <td>9</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Horneland</td>
      <td>21.482500</td>
      <td>8</td>
      <td>85.93</td>
      <td>4</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Jacksonfort</td>
      <td>32.006667</td>
      <td>6</td>
      <td>192.04</td>
      <td>6</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Jacobfort</td>
      <td>24.779355</td>
      <td>52</td>
      <td>768.16</td>
      <td>31</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Jasonfort</td>
      <td>27.831667</td>
      <td>25</td>
      <td>333.98</td>
      <td>12</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>South Roy</td>
      <td>26.031364</td>
      <td>35</td>
      <td>572.69</td>
      <td>22</td>
    </tr>
    <tr>
      <th>96</th>
      <td>South Shannonborough</td>
      <td>26.516667</td>
      <td>9</td>
      <td>397.75</td>
      <td>15</td>
    </tr>
    <tr>
      <th>97</th>
      <td>Spencertown</td>
      <td>23.681154</td>
      <td>68</td>
      <td>615.71</td>
      <td>26</td>
    </tr>
    <tr>
      <th>98</th>
      <td>Stevensport</td>
      <td>31.948000</td>
      <td>6</td>
      <td>159.74</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Stewartview</td>
      <td>21.614000</td>
      <td>49</td>
      <td>648.42</td>
      <td>30</td>
    </tr>
    <tr>
      <th>100</th>
      <td>Swansonbury</td>
      <td>27.464706</td>
      <td>64</td>
      <td>933.80</td>
      <td>34</td>
    </tr>
    <tr>
      <th>101</th>
      <td>Thomastown</td>
      <td>30.308333</td>
      <td>1</td>
      <td>727.40</td>
      <td>24</td>
    </tr>
    <tr>
      <th>102</th>
      <td>Tiffanyton</td>
      <td>28.510000</td>
      <td>21</td>
      <td>370.63</td>
      <td>13</td>
    </tr>
    <tr>
      <th>103</th>
      <td>Torresshire</td>
      <td>24.207308</td>
      <td>70</td>
      <td>629.39</td>
      <td>26</td>
    </tr>
    <tr>
      <th>104</th>
      <td>Travisville</td>
      <td>27.220870</td>
      <td>37</td>
      <td>626.08</td>
      <td>23</td>
    </tr>
    <tr>
      <th>105</th>
      <td>Vickimouth</td>
      <td>21.474667</td>
      <td>13</td>
      <td>322.12</td>
      <td>15</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Webstertown</td>
      <td>29.721250</td>
      <td>26</td>
      <td>475.54</td>
      <td>16</td>
    </tr>
    <tr>
      <th>107</th>
      <td>West Alexis</td>
      <td>19.523000</td>
      <td>47</td>
      <td>390.46</td>
      <td>20</td>
    </tr>
    <tr>
      <th>108</th>
      <td>West Brandy</td>
      <td>24.157667</td>
      <td>12</td>
      <td>724.73</td>
      <td>30</td>
    </tr>
    <tr>
      <th>109</th>
      <td>West Brittanyton</td>
      <td>25.436250</td>
      <td>9</td>
      <td>610.47</td>
      <td>24</td>
    </tr>
    <tr>
      <th>110</th>
      <td>West Dawnfurt</td>
      <td>22.330345</td>
      <td>34</td>
      <td>647.58</td>
      <td>29</td>
    </tr>
    <tr>
      <th>111</th>
      <td>West Evan</td>
      <td>27.013333</td>
      <td>4</td>
      <td>324.16</td>
      <td>12</td>
    </tr>
    <tr>
      <th>112</th>
      <td>West Jefferyfurt</td>
      <td>21.072857</td>
      <td>65</td>
      <td>442.53</td>
      <td>21</td>
    </tr>
    <tr>
      <th>113</th>
      <td>West Kevintown</td>
      <td>21.528571</td>
      <td>5</td>
      <td>150.70</td>
      <td>7</td>
    </tr>
    <tr>
      <th>114</th>
      <td>West Oscar</td>
      <td>24.280000</td>
      <td>11</td>
      <td>704.12</td>
      <td>29</td>
    </tr>
    <tr>
      <th>115</th>
      <td>West Pamelaborough</td>
      <td>33.799286</td>
      <td>27</td>
      <td>473.19</td>
      <td>14</td>
    </tr>
    <tr>
      <th>116</th>
      <td>West Paulport</td>
      <td>33.278235</td>
      <td>5</td>
      <td>565.73</td>
      <td>17</td>
    </tr>
    <tr>
      <th>117</th>
      <td>West Peter</td>
      <td>24.875484</td>
      <td>61</td>
      <td>771.14</td>
      <td>31</td>
    </tr>
    <tr>
      <th>118</th>
      <td>West Sydneyhaven</td>
      <td>22.368333</td>
      <td>70</td>
      <td>402.63</td>
      <td>18</td>
    </tr>
    <tr>
      <th>119</th>
      <td>West Tony</td>
      <td>29.609474</td>
      <td>17</td>
      <td>562.58</td>
      <td>19</td>
    </tr>
    <tr>
      <th>120</th>
      <td>Williamchester</td>
      <td>34.278182</td>
      <td>26</td>
      <td>377.06</td>
      <td>11</td>
    </tr>
    <tr>
      <th>121</th>
      <td>Williamshire</td>
      <td>26.990323</td>
      <td>70</td>
      <td>836.70</td>
      <td>31</td>
    </tr>
    <tr>
      <th>122</th>
      <td>Wiseborough</td>
      <td>22.676842</td>
      <td>55</td>
      <td>430.86</td>
      <td>19</td>
    </tr>
    <tr>
      <th>123</th>
      <td>Yolandafurt</td>
      <td>27.205500</td>
      <td>7</td>
      <td>544.11</td>
      <td>20</td>
    </tr>
    <tr>
      <th>124</th>
      <td>Zimmermanmouth</td>
      <td>28.301667</td>
      <td>45</td>
      <td>679.24</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 5 columns</p>
</div>




```python
merged_tables=pd.merge(clean_city, calc_table, on="city", how="outer")
merged_tables.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>Average Fare</th>
      <th>Total Drivers</th>
      <th>Total Fare</th>
      <th>Total Rides</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>21</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>21</td>
      <td>741.79</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>67</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>67</td>
      <td>535.85</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>16</td>
      <td>Suburban</td>
      <td>37.315556</td>
      <td>16</td>
      <td>335.84</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>21</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>21</td>
      <td>519.75</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>49</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>49</td>
      <td>417.65</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.title=("Pyber Ride Sharing Data 2016")
plt.xlabel=("Total Number of Rides(per City)")
plt.ylabel=("Average Fare ($)")

urban_table=merged_tables.loc[merged_tables['type']=='Urban']
suburbia_table=merged_tables.loc[merged_tables['type']=='Suburban']
rural_table=merged_tables.loc[merged_tables['type']=='Rural']


urban_plt = plt.scatter(urban_table['Total Rides'],urban_table['Average Fare'],marker="o", facecolors="lightcoral", edgecolors="black",
          s=urban_table['Total Drivers']*5,label='Urban', alpha=0.75, linewidths=1.1)
suburbia_plt = plt.scatter(suburbia_table['Total Rides'],suburbia_table['Average Fare'],marker="o", facecolors="lightskyblue", edgecolors="black",
          s=suburbia_table['Total Drivers']*5,label='Suburban', alpha=0.75, linewidths=1.1)
rural_plt = plt.scatter(rural_table['Total Rides'],rural_table['Average Fare'],marker="o", facecolors="gold", edgecolors="black",
          s=rural_table['Total Drivers']*5,label='Rural', alpha=0.8, linewidths=1.1)

lgn=plt.legend(title='city types', loc="best")
lgn.legendHandles[0]._sizes=[50]
lgn.legendHandles[1]._sizes=[50]
lgn.legendHandles[2]._sizes=[50]
plt.ylim(16,45)
plt.xlim(0, 37)
plt.show()
```


![png](output_5_0.png)



```python
fareby_type=merged_tables.groupby("type")["Total Fare"].sum()

rides_type=merged_tables.groupby("type")["Total Rides"].sum()

drivers_type=merged_tables.groupby("type")["Total Drivers"].sum()

pie_table=pd.DataFrame({"Total Fare by type": fareby_type,
                       "Total Rides by type": rides_type,
                       "Total Drivers by type": drivers_type,
                       })
n=pie_table.reset_index()
total_fare=n["Total Fare by type"].sum()
total_ride=n["Total Rides by type"].sum()
total_driver=n["Total Drivers by type"].sum()
```


```python
pie_table.plot(kind="pie",y='Total Drivers by type',shadow=True, autopct="%1.1f%%", explode=[0,0,0.1], colors=["gold", "lightskyblue", "lightcoral"], startangle=90)
plt.axis("equal")
plt.show()
```


![png](output_7_0.png)



```python
pie_table.plot(kind="pie",y='Total Fare by type',shadow=True, autopct="%1.1f%%", explode=[0,0,0.1], colors=["gold", "lightskyblue", "lightcoral"], startangle=90)
plt.axis("equal")
plt.show()
```


![png](output_8_0.png)



```python
pie_table.plot(kind="pie",y='Total Rides by type',shadow=True, autopct="%1.1f%%", explode=[0,0,0.1], colors=["gold", "lightskyblue", "lightcoral"], startangle=90)
plt.axis("equal")
plt.show()
```


![png](output_9_0.png)

